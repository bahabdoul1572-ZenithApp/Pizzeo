
import { GoogleGenAI } from "@google/genai";
import { Language } from "./types";

export class GeminiService {
  private async ensureKeySelected(): Promise<void> {
    const aiWindow = window as any;
    if (typeof aiWindow !== 'undefined' && aiWindow.aistudio) {
      const hasKey = await aiWindow.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await aiWindow.aistudio.openSelectKey();
      }
    }
  }

  private isAuthError(error: any): boolean {
    const errorStr = JSON.stringify(error).toLowerCase();
    const message = error?.message?.toLowerCase() || "";
    return (
      message.includes("permission_denied") || 
      message.includes("403") || 
      message.includes("caller does not have permission") ||
      message.includes("not found") ||
      errorStr.includes("403") ||
      errorStr.includes("permission")
    );
  }

  async askPizzeo(prompt: string, context?: any, language: Language = 'fr'): Promise<string> {
    await this.ensureKeySelected();
    
    // On crée l'instance juste avant l'appel pour avoir la clé la plus fraîche
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction: `You are Pizzeo, an expert assistant for pizzaiolos. 
          Respond in ${language === 'fr' ? 'French' : 'English'} with a professional and passionate tone.
          Contextual recipe data: ${JSON.stringify(context)}.
          Focus on: fermentation, hydration, flour strength (W), and baking tips.`
        }
      });
      return response.text || (language === 'fr' ? "Désolé, je ne peux pas répondre pour le moment." : "Sorry, I can't respond right now.");
    } catch (error: any) {
      console.error("Gemini Text Error:", error);
      if (this.isAuthError(error)) {
        const aiWindow = window as any;
        if (aiWindow.aistudio) await aiWindow.aistudio.openSelectKey();
      }
      throw error;
    }
  }

  async generatePizzaImage(prompt: string): Promise<string | null> {
    // Les modèles Gemini 3 Pro Image nécessitent impérativement une clé payante sélectionnée.
    // En cas d'erreur 403 persistante, on peut basculer sur gemini-2.5-flash-image
    await this.ensureKeySelected();
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: { 
          parts: [{ text: `Professional food photography, close-up of a pizza: ${prompt}. Neapolitan style, artisan crust, warm lighting, 4k.` }] 
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
            imageSize: "1K"
          }
        }
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            return `data:image/png;base64,${part.inlineData.data}`;
          }
        }
      }
      return null;
    } catch (error: any) {
      console.error("Gemini Image Error:", error);
      if (this.isAuthError(error)) {
        const aiWindow = window as any;
        if (aiWindow.aistudio) {
          await aiWindow.aistudio.openSelectKey();
          // Tentative de secours immédiate avec le modèle Flash Image (souvent plus permissif)
          try {
             const flashAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
             const fallback = await flashAi.models.generateContent({
               model: 'gemini-2.5-flash-image',
               contents: { parts: [{ text: `Delicious pizza: ${prompt}` }] }
             });
             for (const part of fallback.candidates[0].content.parts) {
               if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
             }
          } catch(e) { console.error("Fallback Image Error:", e); }
        }
      }
      throw error;
    }
  }
}
